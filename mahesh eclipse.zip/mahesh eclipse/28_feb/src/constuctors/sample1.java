package constuctors;

public class sample1 
{//default constructor
 
	//create object of same class
  public static void main(String[] args)
  {
	
   
	sample1 S1=new sample1();
	//call the method
		S1.multiplication(); 
  }
	
	public void multiplication() 
	{
		int a=10;
		int b=20;
		int mvalue=a*b;
		System.out.println(mvalue);
	}
	
	
	
	
	
	
}
