package Inheritance;

public class whatsappv2 extends whatsappv1
{
  //sub class
 
	public void audiocalling()
	{
		System.out.println("Audio calling");
	}
	
	
}
