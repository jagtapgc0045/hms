package Inheritance;

public class son3 extends H_father
{
public void laptop()
{
	System.out.println("DELL");
}
	
	
}
