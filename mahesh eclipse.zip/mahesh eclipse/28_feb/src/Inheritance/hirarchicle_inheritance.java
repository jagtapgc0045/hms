package Inheritance;

public class hirarchicle_inheritance 
{
  // Hirarchicle inheritance------1 super class & other all sub class
	
	public static void main(String[] args) 
	{
		//create object of different class
		son1 S1=new son1();
		S1.mobile();
		S1.property();
		
		son2 S2=new son2();
		S2.bike();
		S2.property();
		
		son3 S3=new son3();
		S3.laptop();
		S3.property();
		
		
		
		
		
	}
	
	
	
}
