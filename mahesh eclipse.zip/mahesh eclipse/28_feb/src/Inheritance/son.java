package Inheritance;

public class son extends father
{
  //sub class/ child class
	
	public void mobile()
	{
		System.out.println("mobile....samsung 55");
	}
	
	
	
	
	
}
