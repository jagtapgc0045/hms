package Inheritance;

public class father 
{
	//super class/ parent class/ base class
	
public void car()
{
	System.out.println("car.....swift");
}

public void money()
{
	System.out.println("money......5 lakh");
}

public void home() 
{
	System.out.println("home.....2 bhk flat");
}
	
	
	
	
	
	
	
	
}
