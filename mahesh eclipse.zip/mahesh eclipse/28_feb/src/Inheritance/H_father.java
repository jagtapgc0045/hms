package Inheritance;

public class H_father
{

	public void property()
	{
		System.out.println("HOME, CAR, MONEY");
	}
	
	
}
