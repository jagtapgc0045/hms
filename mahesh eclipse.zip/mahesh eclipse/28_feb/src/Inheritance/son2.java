package Inheritance;

public class son2 extends H_father
{

	public void bike()
	{
		System.out.println("UNICORN");
	}
	
}
