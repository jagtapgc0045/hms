package Inheritance;

public class Multi_level_inheritance 
{
	// Multi level inheritance--------3 or more classes
	
public static void main(String[] args) 
{
	//create object of different class
	
	whatsappv3 S1=new whatsappv3();
	
	// call the methods
	S1.textmsg();
	S1.audiocalling();
	S1.videocalling();
	
	
	
	
}
	
	
	
	
	
	
}
