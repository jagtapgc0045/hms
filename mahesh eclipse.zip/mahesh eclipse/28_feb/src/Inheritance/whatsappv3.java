package Inheritance;

public class whatsappv3 extends whatsappv2
{
 public void videocalling()
 {
	 System.out.println("video calling");
 }
	
	
}
