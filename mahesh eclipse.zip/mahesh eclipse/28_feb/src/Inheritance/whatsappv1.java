package Inheritance;

public class whatsappv1 
{
   //super class
	public void textmsg()
	{
		System.out.println("text message");
	}
	
	
}
