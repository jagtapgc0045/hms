package Inheritance;

public class son1 extends H_father
{

	public void mobile()
	{
		System.out.println("SAMSUNG");
	}
	
}
