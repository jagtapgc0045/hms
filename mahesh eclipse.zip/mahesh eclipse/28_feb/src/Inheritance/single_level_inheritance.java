package Inheritance;

public class single_level_inheritance 
{
public static void main(String[] args)
{
	//create object of different class
	
	son S1=new son();
	S1.mobile();
	S1.car();
	S1.home();
	S1.money();
	
	
}
	
	
	
	
	
	
	
	
}
