package keywords_and_identifiers;

public class sample 
{
	//classname, variablename, methodname is nothing but identifiers in java 

	int a=10;                   //a=identifiers
	
	public void m5()            //m5-identifiers
	{
		System.out.println("mahesh");
	}
}
