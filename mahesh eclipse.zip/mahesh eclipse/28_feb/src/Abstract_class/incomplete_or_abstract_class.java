package Abstract_class;

abstract public class incomplete_or_abstract_class 
{
	//complete method
	
 public void m1()
 {
	 System.out.println("method m1 is completed in an abstract class");
 }
	
 // incomplete method /abstract class
	
 abstract public void m2();        //method declaration
 
 // incomplete method /abstract class
 
 abstract public void m3();        //method declaration
}
