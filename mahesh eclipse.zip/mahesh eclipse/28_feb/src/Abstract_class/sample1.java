package Abstract_class;

public class sample1 
{

	public static void main(String[] args) 
	{
		concrete_class C1=new concrete_class();
		C1.m2();
		C1.m3();
		C1.m1();
	}
}
