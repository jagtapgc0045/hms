package Abstract_class;

public class concrete_class extends incomplete_or_abstract_class  
{

	public void m2()      //completed method
	{
		System.out.println("method m2 is completed in concrete class");
	}
	
	public void m3()      //complted method
	{
		System.out.println("method m3 is completed in concrete class");
	}
	
}
