package Abstract_class;

public class complete 
{
	//complete method
	
	public void m1()                     //method declaration
	{
		System.out.println("hi");        //method defination
	}

	public void m2()                    //method declaration
	{
		System.out.println("hello");    //method defination
	}
}
