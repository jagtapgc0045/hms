package datatype;

public class Var231 {
   public static void main(String[]args)   //main method
{
	//variable declaration
	   
	   //Data type  primitive data type
	   
	   //1.numeric & non decimal type
	   //byte  -1 byte
	   //short -2 byte
	   //int   -4 byte
	   //long  -8 byte
	   
	   //2.numeric & decimal type
	   //float -4 byte
	   //double-8 byte
	   
	   //3.single character
	   //char  -2 byte
	   
	   //4.true or false type
	  //boolean-1 bit
	   
	   String studentname;     //datatype variablename; 
	   long rollno;            //datatype variablename;
	   char grade;             //datatype variablename;
	   double percentage;      //datatype variablename;
	   
	//variable initialization
	   
	   studentname="Abhijit";   //variablename =variable information;
	   rollno=185558226566L;    //variablename =variable information;
	   grade='A';               //variablename =variable information;
	   percentage=82.23f;       //variablename =variable information;
	   
	//usage
	   
	   System.out.println("STUDENT NAME: "+studentname);   //printing statement
	   System.out.println("ROLL NO: "+rollno);             //printing statement
	   System.out.println("GRADE: "+grade);                //printing statement
	   System.out.println("PERCENTAGE: "+percentage+"%");  //printing statement
}
}
