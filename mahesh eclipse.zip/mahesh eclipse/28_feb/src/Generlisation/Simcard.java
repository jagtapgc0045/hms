package Generlisation;

public interface Simcard 
{  //super interface

	void sms();    //abstract public void sms();
	
	void audiocalling();
	
	void internet();
}
