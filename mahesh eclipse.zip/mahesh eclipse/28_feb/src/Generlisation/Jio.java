package Generlisation;

public class Jio implements Simcard
{
  public void sms()
  {
	  System.out.println("100 sms");
  }
  public void audiocalling()
  {
	  System.out.println("unlimited");
  }
  public void internet()
  {
	  System.out.println("1.5 GB");
  }
  
  
  
  
}
