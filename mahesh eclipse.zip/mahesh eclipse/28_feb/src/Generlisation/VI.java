package Generlisation;

public class VI implements Simcard
{
	public void sms()
	{
		System.out.println("100 sms");
	}
	public void audiocalling()
	{
		System.out.println("200 Min");
	}
	public void internet()
	{
		System.out.println("3 GB");
	}
	
	
	
	
	
	
	

}
