package Generlisation;

public class Airtel implements Simcard
{
public void sms()
{
	System.out.println("150 sms");
}
public void audiocalling()
{
	System.out.println("100 Min");
}
public void internet()
{
	System.out.println("2 GB");
}






}
