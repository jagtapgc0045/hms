package Loop;

public class loop7 
{
//print even 200 to 2
	public static void main(String[] args)
	{
		for(int i=200; i>=2; i=i-2)
		{
			System.out.println(i);
		}
	}
}
