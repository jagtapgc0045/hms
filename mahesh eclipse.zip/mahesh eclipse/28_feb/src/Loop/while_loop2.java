package Loop;

public class while_loop2 
{
//print hii 10 times
	public static void main(String[] args) 
	{
		int i=1;
		
		while(i<=10)
		{
			System.out.println("hi");
			i++;
		}
	}
}
