package Loop;

public class loop2 
{
	// print 10 to 20
 public static void main(String[] args) 
 {
	for (int i=10; i<=20; i++)
	{
		System.out.println(i);
	}
}

}
