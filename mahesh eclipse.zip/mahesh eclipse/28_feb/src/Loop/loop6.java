package Loop;

public class loop6
{
//print odd 99 to 1
	public static void main(String[] args) 
	{
		for(int i=99; i>=1; i=i-2)
		{
			System.out.println(i);
		}
	}
}
