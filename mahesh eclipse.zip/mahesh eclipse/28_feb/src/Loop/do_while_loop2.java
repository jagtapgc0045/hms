package Loop;

public class do_while_loop2
{
	//printing 2 to 100 even no.
	public static void main(String[] args) {
		
	
	int i=2;     //starting condition
	do
	{
		System.out.println(i);
		i=i+2;      // increment
	}
	while(i<=100);  //end condition
	
	
	

}
}
