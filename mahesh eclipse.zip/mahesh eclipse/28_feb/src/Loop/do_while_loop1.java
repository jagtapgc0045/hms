package Loop;

public class do_while_loop1 
{   //print 1 to 5 no
public static void main(String[] args) 
{
	int i=1;
	
	do
	{
		System.out.println(i);
		i++;
	}
	while(i<=5);
	
	
}
}
