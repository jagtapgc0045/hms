package Loop;

public class while_loop1 
{//printing 1 to 20 no in while loop
public static void main(String[] args) 
{
	int i=1;
	
	while(i<=20)
	{
		System.out.println(i);
		
		i++;
	}
	
	
	
	
}
}
