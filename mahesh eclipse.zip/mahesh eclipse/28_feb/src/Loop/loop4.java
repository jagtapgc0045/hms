package Loop;

public class loop4 
{
	// print odd no 1 to 20
	public static void main(String[] args) {
		
		for(int i=1; i<=20; i=i+2)
		{
			System.out.println(i);
		}
		
	}

}
