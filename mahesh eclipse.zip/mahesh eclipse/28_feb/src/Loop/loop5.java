package Loop;

public class loop5 
{//print 5 to 1
	public static void main(String[] args)
	{
		for(int i=5; i>=1; i--)
		{
			System.out.println(i);
		}
	}

}
