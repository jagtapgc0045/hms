package control_statements;

public class If_else1 
{//If else.........2 condition check
	
public static void main(String[] args) 
{
	int marks=32;
	
	if(marks>=35)
	{
		System.out.println("PASS");
	}
	else
	{
		System.out.println("FAIL");
	}
	
	
	
	
	
	
	
	
}



}
