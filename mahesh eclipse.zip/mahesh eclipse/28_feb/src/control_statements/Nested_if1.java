package control_statements;

public class Nested_if1 
{
public static void main(String[] args) 
{
	
	String username="MAHESH";
	String password="xyz";
	
	if("MAHESH"==username) 
	{
		
		System.out.println("correct username");
		
		if("xyz1"==password) 
		{
			System.out.println("correct password......login sucessfull");
		}
		else
		{
			System.out.println("wrong password.......login failed");
		}
		
	}
	
	else
	{
		System.out.println("wrong username");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
