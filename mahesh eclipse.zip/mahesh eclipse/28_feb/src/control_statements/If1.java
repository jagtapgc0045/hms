package control_statements;

public class If1 
{
	//if....... 1 condition check
public static void main(String[] args) 
{
	int marks=50;        //starting condition
	
	if(marks>=35)
	{
		System.out.println("PASS");
	}
	
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
