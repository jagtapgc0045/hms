package control_statements;

public class else_if1 
{
	// else if........multiple condition check
public static void main(String[] args) 
{
	int marks=62;              //starting condition
	
	if(marks>=65)              //end condition
	{
		System.out.println("distinction");
	}
	else if(marks>=60)
	{
		System.out.println("1 st class");
	}
	else if(marks>=50)
	{
		System.out.println("2 nd class");
	}
	else if(marks>=35)
	{
		System.out.println("pass");
	}
	else
	{
		System.out.println("fail");
	}
	
	
	
	
	
	
	
	
	
}
}
