package polymorphism;

public class test1 
{
   //method overloaading
	
	public void addition(int a,int b)               //method declaration
	{
		int c=a+b;                                  //method defination
		System.out.println(c);
	}
	public void addition(int a,int b,int c)         //method declaration
	{
		int sum=a+b+c;                              //method defination
		System.out.println(sum);
	}
	public void addition(int a,int b,int c,int d)   //method declaration
	{
		int sum1=a+b+c+d;
		System.out.println(sum1);                   //method defination
	}
	
	
	
	
	
}
