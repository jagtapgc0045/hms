package polymorphism;

public class test2 
{
public static void main(String[] args) 
{
	test1 T1=new test1();
	T1.addition(10, 20);
	T1.addition(20, 30, 40);
	T1.addition(40,50,60,70);
}
	
	
}
