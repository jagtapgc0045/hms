package polymorphism;

public class son extends father 
{//sub class

	
	public void mobile()
	{
		System.out.println("mobile.....samsung");
	}
	//method overridden
	public void car()
	   {
		   System.out.println("kia seltos");
	   }
		
		public void money()
		{
			System.out.println("5..lakh");
		}
		public void home()
		{
			System.out.println("4 bhk");
		}
		
	
}
