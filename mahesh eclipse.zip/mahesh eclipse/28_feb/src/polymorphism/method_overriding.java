package polymorphism;

public class method_overriding 
{
public static void main(String[] args)
{
	son S1=new son();
	S1.mobile();
	S1.car();
	S1.money();
	S1.home();
	
	
}	
	
	
	

}
