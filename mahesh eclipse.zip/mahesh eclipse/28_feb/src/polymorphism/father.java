package polymorphism;

public class father 
{
  //method overriding   //super class
	
   public void car()
   {
	   System.out.println("honda city");
   }
	
	public void money()
	{
		System.out.println("1...lakh");
	}
	public void home()
	{
		System.out.println("2 bhk");
	}
	
	
	
	
	
}
