package String;

public class sample1 
{

 public static void main(String[] args)
{
	//String declaration and initialisation
	 
	 String S1="abc";               //without using new keyword
	 
	      //OR
	 
	 String S2=new String("abc"); //classname objectname=new classname();
	 
	 System.out.println(S2);
}	
	
	
	
	
	
	
	
	
	
	
	
	
}
