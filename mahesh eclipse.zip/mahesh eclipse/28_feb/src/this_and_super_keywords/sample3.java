package this_and_super_keywords;

public class sample3
{
  int a=55;
}
