package casting;

public class upcasting2 
{
public static void main(String[] args) 
{
	father2 S2=new son2();
	S2.car();
	S2.money();
	S2.home();
}
}
