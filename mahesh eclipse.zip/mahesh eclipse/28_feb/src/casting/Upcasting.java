package casting;

public class Upcasting 
{
public static void main(String[] args) 
{
	//create object of sub class & provide reference of superclass
	
	father1 S1=new son1();
	S1.car();
	S1.money();
	S1.home();
	
	
	
	
}
	
	
	
	
}
