package casting;

public class son2 extends father2
{
	public void mobile()
	{
		System.out.println("samsung A50");
	}
	public void bike()
	{
		System.out.println("unicorn");
	}
	public void car()
	{
		System.out.println("car---Kia seltos");
	}

	public void money()
	{
		System.out.println("Money--2 lakh");
	} 
	
	

}
