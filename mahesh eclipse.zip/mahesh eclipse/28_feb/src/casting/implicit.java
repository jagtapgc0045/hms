package casting;

public class implicit 
{
public static void main(String[] args) 
{
	int a=5;
	
	System.out.println(a);
	
	double b=a;
	
	System.out.println(b);
	
	
	
}
	
	
	
	
}
