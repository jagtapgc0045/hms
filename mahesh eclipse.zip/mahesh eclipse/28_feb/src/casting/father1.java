package casting;

public class father1 
{

	public void car()
	{
		System.out.println("car---swift");
	}
	
	public void money()
	{
		System.out.println("Money--5 lakh");
	} 
	
	public void home()
	{
		System.out.println("Home--2-BHK");
	}
	
}
