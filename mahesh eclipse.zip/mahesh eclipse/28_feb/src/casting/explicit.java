package casting;

public class explicit 
{
public static void main(String[] args) 
{
	double a=2.5;
	System.out.println(a);
	
	int b=(int)a;
	System.out.println(b);
}
	
	
	
	
	
	
}
