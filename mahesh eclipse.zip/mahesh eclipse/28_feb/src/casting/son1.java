package casting;

public class son1 extends father1 
{
public void mobile()
{
	System.out.println("samsung A50");
}
public void bike()
{
	System.out.println("unicorn");
}
public void car()
{
	System.out.println("car---Kia seltos");
}

public void money()
{
	System.out.println("Money--2 lakh");
} 

public void home()
{
	System.out.println("Home--3-BHK");
}
	
















	
	
	
}
