package variables;

public class variable221 
{
public static void main(String[]args)   //main method
{
	//variable declaration
	
   String studentname;    //datatype variablename;
   int rollno;
   char grade;
   float percentage;
   
   //variable initialization
   
   studentname="MAHESH";   //variablename=variable information;
   rollno=18;
   grade='A';
   percentage=80.36f;
   
   //usage
   
   System.out.println("STUDENT NAME: "+studentname);
   System.out.println("ROLL NO: "+rollno);
   System.out.println("GRADE: "+grade);
   System.out.println("PERCENTAGE: "+percentage+"%");
}
}
