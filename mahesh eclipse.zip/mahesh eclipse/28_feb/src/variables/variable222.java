package variables;

public class variable222 
{
public static void main(String[]args)
{
	String name;
	int no;
	char grade;
	float per;
	
	name="SHUBHAM";
	no=10;
	grade='B';
	per=80.12f;
	
	System.out.println("STUDENT NAME: "+name);
	System.out.println("ROLL NO: "+no);
	System.out.println("GRADE: "+grade);
	System.out.println("PERCENTAGE: "+per);
}
}
