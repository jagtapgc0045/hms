package Type_of_variables;

public class local_variables1 
{
//local variable
	public static void main(String[] args)
	{
		m1(20);     //methodname
	}
	
	public static void m1(int b)
	{
		int a=10;     //local variable
		System.out.println(a);
		System.out.println(b);
	}
	
	
	
	
	
	
}
