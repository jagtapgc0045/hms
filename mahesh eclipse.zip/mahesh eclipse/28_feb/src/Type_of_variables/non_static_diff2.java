package Type_of_variables;

public class non_static_diff2 
{

	int z=100;
	
	
}
