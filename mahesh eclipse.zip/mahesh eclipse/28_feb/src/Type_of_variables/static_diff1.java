package Type_of_variables;

public class static_diff1
{
  public static void main(String[] args)
{
	
	  System.out.println(static_diff2.d);  //classname.variablename
	  
}
	
	
	
	
}
