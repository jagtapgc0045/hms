package Type_of_variables;

public class static_diff2
{
//static global variable
	
	static int d=80;
}
