package Type_of_variables;

public class static_same1
{
	// static global/class variable call from same class
	
  static int c=70;
	
 public static void main(String[] args) 
{
	System.out.println(c);
}
	
	
	
	
	
	
	
	
	
}
