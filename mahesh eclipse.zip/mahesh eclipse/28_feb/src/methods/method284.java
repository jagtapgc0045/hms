package methods;

public class method284 
{
public void Mahesh1234(String name, int rollno)
{
	System.out.println(name);
	System.out.println(rollno);
}
	
}
