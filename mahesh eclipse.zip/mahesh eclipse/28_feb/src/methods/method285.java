package methods;

public class method285
{
public static void main(String[]args)
{
	ABC("ABHIJIT",125,'A');                               //methodname.();
	System.out.println("-----------------------------");
	ABC("AKSHAY",156,'B');                                //methodname.();
	System.out.println("-----------------------------");
	ABC("ADITYA",155,'C');                                //methodname.();
	System.out.println("-----------------------------");
	
}
//static regular method with parameter------string char int....

  public static void ABC(String sname,int Rollno,char Grade)
  {
	  System.out.println("STUDENT NAME : "+sname);
	  System.out.println("ROLL NO : "+Rollno);
	  System.out.println("GRADE : "+Grade);
  }







}
