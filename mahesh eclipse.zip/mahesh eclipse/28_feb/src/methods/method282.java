package methods;

public class method282 
{
public static void main(String[]args)
{
	mahesh();
	mahesh1(555,222);
	mahesh2(123.5f,10.56f);
	mahesh3(2,2,5,5);
	mahesh4('Z');
	mahesh5("MAHESH");
}
	
	public static void mahesh()
	{
		int a=111;
		int b=222;
		int c=a+b;
		
		System.out.println(c);
	}
	public static void mahesh1(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	public static void mahesh2(double a, double b)
	{
		double c=a+b;
		System.out.println(c);
	}
	
	public static void mahesh3(int a, int b, int c, int d)
	{
		int e=a*b*c*d;
		System.out.println(e);
	}
	public static void mahesh4(char grade)
	{
		System.out.println(grade);
	}
	public static void mahesh5(String studentname)
	{
		System.out.println(studentname);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
