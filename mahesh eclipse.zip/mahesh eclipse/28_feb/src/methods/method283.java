package methods;

public class method283 
{
public static void main(String[]args)
{
	studentname("MAHESH",'A',18,80.36f);

	System.out.println("-------------------------");
	method284 AZ=new method284();
	AZ.Mahesh1234("SHUBHAM",77);
	
	
}
public static void studentname(String sname,char grade,int rollno,float per)
{
	System.out.println("STUDENT NAME :"+sname);
	System.out.println("GRADE"+grade);
	System.out.println("ROLL NO :"+rollno);
	System.out.println("PERCENTAGE :"+per);
}









}
