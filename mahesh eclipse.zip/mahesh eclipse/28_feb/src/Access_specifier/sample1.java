package Access_specifier;

public class sample1 
{
	// public ----access specifier
	// use the method for whole project means all packages
public int a=10;
public static void main(String[] args) 
{
	
}
	public void m1()
	{
		System.out.println("good afternoon");
	}
	public void m2()
	{
		System.out.println("GOOD MORNING");
	}
}
