package Access_specifier;

public class sample7 
{
  //protected----access specifier call from different class
	
	public static void main(String[] args) 
	{
		//create object
		sample6 A2=new sample6();
		A2.m25();
		System.out.println(A2.a);
		
	}
	
}
