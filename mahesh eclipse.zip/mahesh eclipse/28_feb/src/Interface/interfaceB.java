package Interface;

public interface interfaceB 
{
 void m3();     //abstract public void m3();
 
 void m4();      //abstract public void m4();
	
	
}
