package Interface;

public interface interfaceA 
{

	void m1();  //abstract public void m1();
	
	void m2();  //abstract public void m1();
	
}
