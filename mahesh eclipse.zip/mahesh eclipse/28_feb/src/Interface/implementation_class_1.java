package Interface;

public class implementation_class_1 implements interfaceA, interfaceB 

{
public void m1()
{
	System.out.println("Hii");
}
public void m2()
{
	System.out.println("hello");
}
public void m3()
{
	System.out.println("Good morning");
}
public void m4()
{
	System.out.println("Good night");
}
}
