package Interface;

public class sample1
{

	public static void main(String[] args) 
	{
		
		implementation_class A1=new implementation_class();
		A1.m1();
		A1.m2();
	}
}
