package Interface;

public class sample2 
{

	public static void main(String[] args) 
	{
		
		implementation_class_1 I1=new implementation_class_1();
		I1.m1();
		I1.m2();
		I1.m3();
		I1.m4();
	}
}
