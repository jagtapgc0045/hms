package Interface;

public class implementation_class implements interface1 
{

	public void m1()
	{
		System.out.println("method m1 is completed in an implementation class");
	}
	
	public void m2()
	{
		System.out.println("method m2 is completed in an implementation class");
	}
	
}
