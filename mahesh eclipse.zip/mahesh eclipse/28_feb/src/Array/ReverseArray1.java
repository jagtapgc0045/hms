package Array;

public class ReverseArray1 
{
	public static void main(String[] args) 
	{
		//Reverse array
		
		//Array declaration
		
		int[] ar=new int[5];
		
		//Array initialisation
		
		ar[0]=300;
		ar[1]=100;
		ar[2]=200;
		ar[3]=400;
		ar[4]=500;
		
		//usage
		
		for(int i=4; i>=0; i--)
		{
			System.out.println(ar[i]);
		}
		
		
	}
	
	
	
	
	
	
	
	

}
