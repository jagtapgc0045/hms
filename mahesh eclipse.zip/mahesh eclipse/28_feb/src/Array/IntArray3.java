package Array;

public class IntArray3 
{
public static void main(String[] args) 
{
	//Array declaration
	
			int[] ar=new int[5];
			
			//Array initialisation
			
			ar[0]=300;
			ar[1]=100;
			ar[2]=200;
			ar[3]=400;
			
			
			//usage
			
			System.out.println(ar[0]);
			System.out.println(ar[1]);
			System.out.println(ar[2]);
			System.out.println(ar[3]);
			System.out.println(ar[4]);
		
		    //OR
			
	   System.out.println("---------------------------");
		
	   
	   for(int i=0; i<=4; i++)
	   {
		   System.out.println(ar[i]);
	   }
		
	
	
	
	
}
	
	
	
	
	
	
	
	
}
