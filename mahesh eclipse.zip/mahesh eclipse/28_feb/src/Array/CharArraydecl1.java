package Array;

import java.util.Arrays;

public class CharArraydecl1 
{
  public static void main(String[] args)
 {
	char[] A= {'Z','A','H','R','T','B'};
	  
	  
	  Arrays.sort(A);
	  
	for(int i=0; i<=A.length-1; i++)
	{
		System.out.println(A[i]);
	}
	  
	  
	  
	  
	  
	  
 }
}
