package Array;

import java.util.Arrays;

public class StringArrayDecla1
{
	public static void main(String[] args)
	{
	    //ARRAY DECLARATION AND INITIALISATION
		
		String[] B= {"VIRAT","ROHIT","MSD","RAHUL"};
		
		//USAGE
		
		Arrays.sort(B);
		
		for(int i=0; i<=B.length-1; i++) 
		{
			System.out.println(B[i]);
		}
		
		
		
		
		
		
	}

}
