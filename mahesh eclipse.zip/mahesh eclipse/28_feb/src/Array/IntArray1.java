package Array;

public class IntArray1 
{
public static void main(String[] args) 
{
	//Array declaration
	
	int[] ar=new int[5];
	
	//Array initialisation
	
	ar[0]=300;
	ar[1]=100;
	ar[2]=200;
	ar[3]=400;
	ar[4]=500;
	
	//usage
	
	System.out.println(ar[0]);
	System.out.println(ar[1]);
	System.out.println(ar[2]);
	System.out.println(ar[3]);
	System.out.println(ar[4]);
}

 
	
}
