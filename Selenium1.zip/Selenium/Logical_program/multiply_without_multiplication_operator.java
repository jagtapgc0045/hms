package Logical_program;

public class multiply_without_multiplication_operator 
{
	public static void main(String[] args) 
	{
		int num1=5;
		
		int num2=2;
		
		int sum=0;
		
		for(int i=1; i<=num1; i++)
		{
			sum=sum+num2;
		}
		System.out.println(sum);
	}

}
