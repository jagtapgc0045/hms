package Open_Browser;

import org.openqa.selenium.chrome.ChromeDriver;

public class Launch_browser 
{

	public static void main(String[] args) 
	{
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\computer1\\Desktop\\Selenium\\Browser\\chromedriver_win32\\chromedriver.exe");
		
		ChromeDriver driver=new ChromeDriver();
		
		
		
	}
	
	
	
	
}
