package Star_Pattern;

public class Star1 
{
	//* * * *
	
	public static void main(String[] args) 
	{
		for(int i=1; i<=4; i++)
		{
			System.out.print("*"+" ");
		}
	}

}
